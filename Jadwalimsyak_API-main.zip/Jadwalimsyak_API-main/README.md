# Jadwalimsyak_API
tugas UTS Pemrograman 2 membuat layanan web service (REST API) untuk melihat jadwal sholat dan imsakiyah Ramadhan 1444 H/2023 M menggunakan bahasa pemrograman python atau framework Django

# Sumber Data Jadwal Imsyakiah Ramadhan 1444 H untuk wilayah Lombok Timur dan Sekitarnya bersumber dari L-FAS Nahdlatul Wathan
https://drive.google.com/file/d/1Z_si53QrGDuFLHU7ismHYDllKOsy3fKf/view?usp=share_link
