from django.apps import AppConfig


class JadwalImsyakConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'jadwal_imsyak'
