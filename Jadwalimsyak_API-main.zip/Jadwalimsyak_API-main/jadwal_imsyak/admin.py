from django.contrib import admin
from . models import jadwal

# Register your models here.
admin.site.register(jadwal),
